import React from 'react'

const FlightRequests = () => {
  return (
    <div>FlightRequests</div>
  )
}

export default FlightRequests